﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MediatR;
using System.Reflection;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using EF_WWT.Data;

namespace EF_WWT
{
    public class Startup
    {
        private readonly ApiConfig _configuration;

        public Startup(IHostingEnvironment env)
        {
            _configuration = new ApiConfig(env.EnvironmentName);
        }

        public IConfiguration Configuration { get; }       

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc()
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_2)
                .AddJsonOptions(options => options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);

            //Add EF core
            services.AddDbContext<EFWWTContext>((opts) => opts.UseSqlServer(_configuration.EFWWTConnectionString),  ServiceLifetime.Transient);

            //register Automapper + Mediatr + ... 
            var currentAssembly = typeof(Startup).GetTypeInfo().Assembly;
            //auto-register all MediatR classes. Otherwise we'd need to register them manually
            services.AddMediatR(currentAssembly);
            //Automapper dependencies
            services.AddAutoMapper(currentAssembly);

            //var mappingConfig = new MapperConfiguration()
            

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseMvc();
        }
    }
}
