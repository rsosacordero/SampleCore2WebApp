﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EF_WWT;
using EF_WWT.Data;
using EF_WWT.CQRS.Queries;

namespace EF_WWT.Profiles
{
    public class ContactProfile : Profile
    {
        public ContactProfile() =>
            //CreateMap<List<GetContactByName>, GetContactByNameQueryResponse>()
            //    .ForMember(dest => dest.Addresses, o => o.MapFrom(src => src.Select(c => c.Address)))
            //    .ForMember(dest => dest.FirstName, o => o.MapFrom(src => src.First().FirstName))
            //    .ForMember(dest => dest.LastName, o => o.MapFrom(src => src.First().LastName))
            //    .ForMember(dest => dest.Id, o => o.MapFrom(src => src.First().BusinessEntityID));


            CreateMap<List<GetContactByName>, List<GetContactByNameQueryResponse>>();
           
                
    }
}
