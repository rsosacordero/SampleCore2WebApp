﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using EF_WWT.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace EF_WWT.CQRS.Queries
{
    public class GetContactByNameQuery : IRequest<List<GetContactByNameQueryResponse>>
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
    public class GetContactByNameQueryResponse
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public List<string> Addresses { get; set; }
    }

    public class GetContactByNameQueryHandler : IRequestHandler<GetContactByNameQuery, List<GetContactByNameQueryResponse>>
    {
        private readonly EFWWTContext _context;
        private readonly IMapper _mapper;
        public GetContactByNameQueryHandler(EFWWTContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<GetContactByNameQueryResponse>> Handle(GetContactByNameQuery request, CancellationToken cancellationToken)
        {
            var result = await _context.Query<GetContactByName>().FromSql("EXEC dbo.GetContactByName @FirstName={0}, @LastName={1}", request.FirstName, request.LastName).ToListAsync();

            var mappedResult = _mapper.Map<List<GetContactByNameQueryResponse>>(result);

            return mappedResult;
        }
    }
}
