﻿using System.Threading.Tasks;
using EF_WWT.CQRS.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace EF_WWT.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        private readonly IMediator Mediator;

        public PersonController(IMediator mediator)
        {
            Mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> GetContactByNameAsync([FromQuery] GetContactByNameQuery query)
        {
             var result = await Mediator.Send(query);
             return Ok(result);
        }

    }
}